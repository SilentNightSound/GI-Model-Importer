This is a development version of 3dmigoto GIMI. Original program from https://github.com/bo3b/3Dmigoto.

I have modified the 3dmigoto .dll and .ini for compatability with genshin, and turned on most of the features of the 3dmigoto plugin. 

I update the features of this program from time to time, so check back at https://github.com/SilentNightSound/GI-Model-Importer to see if there are any updates.

Place any mods created in the Mods folder and press F10 in game in order to load them.

If you have any questions or issues, please open an issue on the github page or send me a DM on discord (SilentNightSound#7430)